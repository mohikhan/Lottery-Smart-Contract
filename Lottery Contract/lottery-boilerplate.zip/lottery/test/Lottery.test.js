const ganache = require('ganache');
const { Web3 } = require('web3');
// updated imports added for convenience
